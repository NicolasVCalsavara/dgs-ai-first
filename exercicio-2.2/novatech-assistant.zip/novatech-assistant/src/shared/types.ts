/**
 * Tipos base para o endpoint de query.
 * S-1: tipos mínimos necessários apenas para validação de input e resposta stub.
 */

export interface QueryRequest {
  query: string;
}

export interface SourceDocument {
  id: string;
  title: string;
  url: string;
  relevance_score: number;
}

export interface QueryResponse {
  response: string;
  source_document: SourceDocument;
}
