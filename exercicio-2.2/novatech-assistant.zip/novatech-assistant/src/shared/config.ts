/**
 * Configuração da aplicação carregada de variáveis de ambiente.
 * Falha rápido se variáveis obrigatórias faltarem.
 * S-1: carrega apenas as essenciais para esta fase.
 */

interface Config {
  environment: "development" | "production";
  logLevel: "debug" | "info" | "warn" | "error";
}

let cachedConfig: Config | null = null;

function loadConfig(): Config {
  if (cachedConfig) {
    return cachedConfig;
  }

  const environment = (process.env.NODE_ENV || "development") as "development" | "production";

  if (!environment || !["development", "production"].includes(environment)) {
    throw new Error(
      `[Config] NODE_ENV must be 'development' or 'production', got: ${environment}`
    );
  }

  const logLevel = (process.env.LOG_LEVEL || "info") as "debug" | "info" | "warn" | "error";
  if (!["debug", "info", "warn", "error"].includes(logLevel)) {
    throw new Error(
      `[Config] LOG_LEVEL must be one of 'debug', 'info', 'warn', 'error', got: ${logLevel}`
    );
  }

  cachedConfig = {
    environment,
    logLevel,
  };

  return cachedConfig;
}

export const config = loadConfig();
