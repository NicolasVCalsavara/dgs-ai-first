/**
 * Erros customizados da aplicação.
 * S-1: ValidationError apenas.
 */

export class ValidationError extends Error {
  public readonly statusCode = 400;
  public readonly details: Record<string, string[]>;

  constructor(message: string, details: Record<string, string[]> = {}) {
    super(message);
    this.name = "ValidationError";
    this.details = details;
    Object.setPrototypeOf(this, ValidationError.prototype);
  }
}
