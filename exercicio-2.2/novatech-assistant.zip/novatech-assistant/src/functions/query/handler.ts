/**
 * HTTP trigger para POST /api/query.
 * S-1: scaffold com validação de input e resposta stub tipada.
 * Não chama serviços — retorna QueryResponse stub e monta erro 400 para input inválido.
 */

import { app, HttpRequest, HttpResponseInit } from "@azure/functions";
import { validateQueryRequest } from "./validator";
import { QueryRequest, QueryResponse, SourceDocument } from "../../shared/types";
import { ValidationError } from "../../shared/errors";
import { config } from "../../shared/config";

export async function query(request: HttpRequest): Promise<HttpResponseInit> {
  try {
    // Leia o body e valide
    const body: unknown = await request.json().catch(() => ({}));
    const queryRequest: QueryRequest = validateQueryRequest(body);

    // S-1: resposta stub com QueryResponse tipada
    const stubSource: SourceDocument = {
      id: "stub-doc-001",
      title: "Sample Document",
      url: "https://example.com/doc",
      relevance_score: 0.95,
    };

    const response: QueryResponse = {
      response:
        "This is a stub response for: " +
        queryRequest.query +
        ". Implementation progresses in S-2.",
      source_document: stubSource,
    };

    return {
      status: 200,
      jsonBody: response,
    };
  } catch (error) {
    if (error instanceof ValidationError) {
      return {
        status: 400,
        jsonBody: {
          error: error.message,
          details: error.details,
        },
      };
    }

    // Erro inesperado
    const errorMessage = error instanceof Error ? error.message : String(error);
    return {
      status: 500,
      jsonBody: {
        error: "Internal server error",
        message:
          config.environment === "development" ? errorMessage : "An unexpected error occurred",
      },
    };
  }
}

app.http("query", {
  methods: ["POST"],
  authLevel: "anonymous",
  handler: query,
});
