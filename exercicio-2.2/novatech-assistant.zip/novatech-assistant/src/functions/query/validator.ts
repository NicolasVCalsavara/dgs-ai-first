/**
 * Validação de input para o endpoint /api/query.
 * Usa Zod para schema validation com mensagens descritivas.
 * S-1: valida apenas QueryRequest.
 */

import { z } from "zod";
import { QueryRequest } from "../../shared/types";
import { ValidationError } from "../../shared/errors";

const QueryRequestSchema = z.object({
  query: z
    .string({ required_error: "query is required" })
    .min(5, "query must be at least 5 characters long")
    .max(1000, "query must not exceed 1000 characters"),
});

export function validateQueryRequest(input: unknown): QueryRequest {
  try {
    return QueryRequestSchema.parse(input);
  } catch (error) {
    if (error instanceof z.ZodError) {
      const details: Record<string, string[]> = {};
      for (const issue of error.issues) {
        const fieldPath = issue.path.join(".");
        if (!details[fieldPath]) {
          details[fieldPath] = [];
        }
        details[fieldPath].push(issue.message);
      }
      throw new ValidationError("Invalid query request", details);
    }
    throw error;
  }
}
