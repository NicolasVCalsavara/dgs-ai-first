/**
 * Testes unitários do validator de QueryRequest.
 * S-1: cobre casos de validação bem-sucedida, input inválido com detalhes de erro.
 */

import { describe, it, expect } from "vitest";
import { validateQueryRequest } from "../../functions/query/validator";
import { ValidationError } from "../../shared/errors";

describe("validateQueryRequest", () => {
  it("should validate a valid query request", () => {
    const input = { query: "What is artificial intelligence?" };
    const result = validateQueryRequest(input);

    expect(result).toEqual({ query: "What is artificial intelligence?" });
  });

  it("should reject missing query field", () => {
    const input = {};

    expect(() => validateQueryRequest(input)).toThrow(ValidationError);
    try {
      validateQueryRequest(input);
    } catch (error) {
      if (error instanceof ValidationError) {
        expect(error.message).toContain("Invalid query request");
        expect(error.details.query).toBeDefined();
        expect(error.details.query[0]).toContain("required");
      }
    }
  });

  it("should reject query that is too short", () => {
    const input = { query: "abc" };

    expect(() => validateQueryRequest(input)).toThrow(ValidationError);
    try {
      validateQueryRequest(input);
    } catch (error) {
      if (error instanceof ValidationError) {
        expect(error.details.query).toBeDefined();
        expect(error.details.query[0]).toContain("at least 5 characters");
      }
    }
  });

  it("should reject query that is too long", () => {
    const input = { query: "a".repeat(1001) };

    expect(() => validateQueryRequest(input)).toThrow(ValidationError);
    try {
      validateQueryRequest(input);
    } catch (error) {
      if (error instanceof ValidationError) {
        expect(error.details.query).toBeDefined();
        expect(error.details.query[0]).toContain("must not exceed 1000 characters");
      }
    }
  });

  it("should reject non-string query", () => {
    const input = { query: 123 };

    expect(() => validateQueryRequest(input)).toThrow(ValidationError);
    try {
      validateQueryRequest(input);
    } catch (error) {
      if (error instanceof ValidationError) {
        expect(error.details.query).toBeDefined();
      }
    }
  });

  it("should reject query field that is an empty string", () => {
    const input = { query: "" };

    expect(() => validateQueryRequest(input)).toThrow(ValidationError);
    try {
      validateQueryRequest(input);
    } catch (error) {
      if (error instanceof ValidationError) {
        expect(error.details.query).toBeDefined();
        expect(error.details.query[0]).toContain("at least 5 characters");
      }
    }
  });

  it("should validate query at boundary length (exactly 5 chars)", () => {
    const input = { query: "hello" };
    const result = validateQueryRequest(input);

    expect(result.query).toBe("hello");
  });

  it("should validate query at boundary length (exactly 1000 chars)", () => {
    const input = { query: "a".repeat(1000) };
    const result = validateQueryRequest(input);

    expect(result.query.length).toBe(1000);
  });

  it("should return ValidationError with 400 status code", () => {
    const input = { query: "x" };

    try {
      validateQueryRequest(input);
    } catch (error) {
      if (error instanceof ValidationError) {
        expect(error.statusCode).toBe(400);
        expect(error.name).toBe("ValidationError");
      }
    }
  });
});
